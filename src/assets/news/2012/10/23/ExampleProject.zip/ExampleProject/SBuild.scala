import de.tototec.sbuild._
import de.tototec.sbuild.TargetRefs._

class SBuild(implicit project: Project) {

  SchemeHandler("http", new HttpSchemeHandler())
  SchemeHandler("mvn", new MvnSchemeHandler())
  SchemeHandler("zip", new ZipSchemeHandler())

  val dependencies =
    "libs/a-local-jar.jar" ~
    "http://cmdoption.tototec.de/cmdoption/attachments/download/3/de.tototec.cmdoption-0.1.0.jar" ~
    "mvn:org.slf4j:slf4j-api:1.7.0" ~
    "zip:file=junit4.10/junit-4.10.jar;archive=http://cloud.github.com/downloads/KentBeck/junit/junit4.10.zip"
    
  ExportDependencies("eclipse.classpath", dependencies)

}